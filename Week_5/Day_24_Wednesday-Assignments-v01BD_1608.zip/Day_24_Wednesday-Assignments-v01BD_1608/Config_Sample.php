<?php
define ('DB_HOST', 'localhost');
define ('DB_USER', 'sakila');
define ('DB_PASSWORD', 'sakila@2016');
define ('DB_DATABASE', 'sakila');
?>
